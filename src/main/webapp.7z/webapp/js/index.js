layui.use(['form','jquery','jquery_cookie','http'], function () {
    var form = layui.form,
        layer = layui.layer,
        $ = layui.jquery,
        $ = layui.jquery_cookie($);
    var http = layui.http;
    var path = http.path;

    // 进行登录操作
    form.on('submit(login)', function (data) {
        var data = data.field;
        if ( data.username =="undefined" || data.username =="" || data.username.trim()=="") {
            layer.msg('用户名不能为空');
            return false;
        }
        if ( data.password =="undefined" || data.password =="" || data.password.trim()=="")  {
            layer.msg('密码不能为空');
            return false;
        }
        $.ajax({
            type:"post",
            url:path+"/user/login",
            data:{
                username:data.username,
                password:data.password,
                rememberMe:data.rememberMe
            },
            dataType:"json",
            success:function (data) {
                if(data.code==200){
                   /* layer.msg('登录成功', function () {
                        window.location.href=path+"/main";
                    });*/
                    window.location.href=path+"/main";
                }else{
                    layer.msg(data.msg);
                }
            }
        });
        return false;
    });
});