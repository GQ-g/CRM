/**
 * 封装统一的工程路径
 */

layui.define(function (exports) {
    var obj = {
        path:'/crm'
    };
    exports("http", obj);
});